//#pragma once
#ifndef WochentagFunktionen_h
#define WochentagFunktionen_h

#include <string>
using namespace std;

bool schalt(int year);
bool dateCheck(int day, int month, int year);
int get_days_of_month(int month, int year);
string weekday(int day, int month, int year);


#endif

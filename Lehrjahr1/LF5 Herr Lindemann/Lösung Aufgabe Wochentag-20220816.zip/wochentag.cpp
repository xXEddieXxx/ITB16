#include <iostream>
#include "WochentagFunktionen.h"
using namespace std;

///bool schalt(int year);
///bool dateCheck(int day, int month, int year);
///int get_days_of_month(int month, int year);
///string weekdays[7] = { "Samstag","Sonntag","Montag","Dienstag", "Mittwoch","Donnerstag","Freitag" };
///string weekday(int day, int month, int year);


int main()
{
    int day;
    int month;
    int year;

    cout << "Input day: ";
    cin >> day;
    cout << endl << "Input month: ";
    cin >> month;
    cout << endl << "Input year: ";
    cin >> year;

    if (dateCheck(day, month, year)) {
        cout << endl << weekday(day, month, year);
        system("pause");
    }
    else {
        cout << endl << "Date invalid";
        system("pause");
        exit;
    }


}

/*
bool schalt(int year) {
    bool schalt = true;
    if (year % 4 != 0) {
        if (year % 100 != 0) {
            if (year % 400 != 0) {
                schalt = false;
            }
            schalt = false;
        }
        schalt = false;
    }
    return schalt;
}

bool dateCheck(int day, int month, int year) {

    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
        if (day > 31 || day < 0) {
            return false;
        }
    }
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        if (day > 30 || day < 0) {
            return false;
        }
    }
    if (month == 2) {
        if (schalt(year)) {
            if (day > 29) {
                return false;
            }
        }
        else {
            if (day > 28) {
                return false;
            }
        }
    }
    if (month > 12 || month <= 0) {
        return false;
    }
    return true;
}

int get_days_of_month(int month, int year) {
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
        return 31;
    }
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        return 30;
    }
    if (month == 2) {
        if (schalt(year)) {
            return 29;
        }
        else {
            return 28;
        }
    }
    return 30;
}


string weekday(int day, int month, int year) {
    int tmp_years = 1900;
    int total_days = 0;
    while (tmp_years != year) {
        if (schalt(tmp_years)) {
            total_days += 366;
        }
        else {
            total_days += 365;
        }
        tmp_years++;
    }
    total_days += day;
    month--;
    while (month > 0) {
        total_days += get_days_of_month(month, year);
        month--;
    }
    return weekdays[total_days % 7];
}
*/